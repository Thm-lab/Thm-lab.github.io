## Description
This network has a gateway which can connect to the Internet network and the gateway is responsible for obtain  

information sented from external network.
In this network, there are 8 external routers each of which is connected to the computer terminal.  

The information sented by Internet must be forwarded to computer terminal through the gateway and external routers.  

Every 10 seconds, each routers will boardcast its connection information which contains its connection cost with every routers and gateway. The connection cost between two routers which is not connected is +INF.
## Data Structure
Due to the different function for gateway and routers, I set up some different data structure to describe the data how to be stored in RAM.  
The class of Gateway and Router as follows.
``` c++
struct Gateway {    
    int connection_matrix[router_num][router_num];
    struct Routing_table[8];
}
struct Router {
    int ip;
    struct routing_table;    
}
```
1. **gateway**  
  >- routing table  
``` c++
struct Routing table {
    Router source_router;
    Router target_router;
    Router forward_router;
}
```
  >- connection table
``` c++
/* n is number of routers
 * n = 8;
 * connection_matrix[i][i] = 0;
*/
connection_matrix[n][n];
```
2. **routers**
  >- routing table  
  ``` c++
struct Routing_table {
    router source_router;
    router target_router;
    router forward_router;
}
```
>- connection list
``` c++
/* n is number of routers
 * n = 8;
 * for router i
 * connection_list[i] = 0;
*/
connection_list[n];
```
## Test matrix
$$
\left[
  \begin{array}{ccc}
    0 & 1 & 1 & 4 & INF & 2 & 5 & INF\\
    1 & 0 & INF & INF & INF & 2 & INF & 4\\
    1 & INF & 0 & INF & INF & INF & 3 & INF\\
    4 & INF & INF & 0 & 1 & INF & INF & INF\\
    INF & INF & INF & 1 & 0 & 1 & INF & INF\\
    2 & 2 & INF & INF & 1 & 0 & INF & INF\\
    5 & INF & 3 & INF & INF & INF & 0 & 1\\
    INF & 4 & INF & INF & INF & INF & 1 & 0
  \end{array}
\right]
$$