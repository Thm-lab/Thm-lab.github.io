#include <algorithm>
#include <cstring>
#include <iostream>
#include "macro.h"
#include "printProject.h"

// for write json files
#include <jsoncpp/json/json.h>
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

// Router MAC
#define RouterX 2

void readJson(Routing_table& routing_table, int ip);
void boardcastConnection(int connection[ROUTER_NUM], int ip);

int main() {
  // declare routing_table and initialize it as RouterX
  Routing_table routing_table;
  routing_table.cost = 0;
  routing_table.local_router.ip = RouterX;
  routing_table.source_router.ip = RouterX;
  routing_table.target_router.ip = RouterX;
  routing_table.forward_router.ip = RouterX;

  readJson(routing_table, routing_table.local_router.ip);

  // print for debug
  // cout << "Router" << RouterX << "'s forward cost is : " <<
  // routing_table.cost
  //      << "\n";
  // cout << "Router" << RouterX
  //      << "'s source_router is Router: " << routing_table.source_router.ip
  //      << "\n";
  // cout << "Router" << RouterX
  //      << "'s target_router is Router: " << routing_table.target_router.ip
  //      << "\n";
  // cout << "Router" << RouterX
  //      << "'s forward_router is Router: " << routing_table.forward_router.ip
  //      << "\n";
  int connection[ROUTER_NUM] = {6, 2, 5, 7, INF, INF, INF, INF};
  boardcastConnection(connection, routing_table.local_router.ip);
  return 0;
}

void readJson(Routing_table& routing_table, int ip) {
  Json::Reader reader;
  Json::Value root;

  ifstream in("attribution.json", ios::binary);
  if (!in.is_open()) {
    cout << "Error opening file\n";
    return;
  }

  // parse root
  if (reader.parse(in, root)) {
    routing_table.cost = root["routing_table"][ip]["cost"].asInt();
    routing_table.local_router.ip =
        root["routing_table"][ip]["local_router"]["ip"].asInt();
    routing_table.source_router.ip =
        root["routing_table"][ip]["source_router"]["ip"].asInt();
    routing_table.target_router.ip =
        root["routing_table"][ip]["target_router"]["ip"].asInt();
    routing_table.forward_router.ip =
        root["routing_table"][ip]["forward_router"]["ip"].asInt();
  } else {
    cout << "parse error" << endl;
  }

  in.close();
}

void boardcastConnection(int connection[ROUTER_NUM], int ip) {
  Json::Value root;
  Json::Reader reader;

  ifstream in("attribution.json", ios::binary);
  if (!in.is_open()) {
    cout << "Error opening file\n";
    return;
  }

  if (reader.parse(in, root)) {
    for (int i = 0; i < ROUTER_NUM; i++) {
      root["connection_matrix"][ip][i] = connection[i];
    }
  }
  in.close();

  Json::StyledWriter sw;
  ofstream os;
  os.open("attribution.json", std::ios::out);
  os << sw.write(root);
  os.close();
}