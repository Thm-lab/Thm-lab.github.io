#include <algorithm>
#include <cstring>
#include <iostream>
#include "macro.h"
#include "printProject.h"

// for write json files
#include <jsoncpp/json/json.h>
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

void dijkstra(int connection_matrix[ROUTER_NUM][ROUTER_NUM],
              int begin,
              int distance[ROUTER_NUM],
              int pre_router[ROUTER_NUM]);
void getPath(int pre_router[ROUTER_NUM], int begin, int target);
void getRouting_table(struct Gateway& gateway_ptr);
void writeJson(struct Gateway& gateway);

int main() {
  // print information of this program
  printProject();
  // initialize all the routers in this network and attribute them unique ip
  // address
  struct Router routers[ROUTER_NUM];
  for (int i = 0; i < ROUTER_NUM; i++) {
    routers[i].ip = i;
  }
  // declare the routing_table for each router. Firstly, they are initialized by
  // themselves
  struct Routing_table routing_tables[ROUTER_NUM];
  for (int i = 0; i < ROUTER_NUM; i++) {
    routing_tables[i] = {.cost = 0,
                         .local_router = routers[i],
                         .source_router = routers[i],
                         .target_router = routers[i],
                         .forward_router = routers[i]};
  }
  // initialize gateway, store the earliest connection_matrix
  struct Gateway gateway = {
      .connection_matrix = {{0, 1, 1, 4, INF, 2, 5, INF},
                            {1, 0, INF, INF, INF, 2, INF, 4},
                            {1, INF, 0, INF, INF, INF, 3, INF},
                            {4, INF, INF, 0, 1, INF, INF, INF},
                            {INF, INF, INF, 1, 0, 1, INF, INF},
                            {2, 2, INF, INF, 1, 0, INF, INF},
                            {5, INF, 3, INF, INF, INF, 0, 1},
                            {INF, 4, INF, INF, INF, INF, 1, 0}},
      .routing_table = {}};
  for (int i = 0; i < ROUTER_NUM; i++) {
    gateway.routing_table[i] = routing_tables[i];
  }

  // print for debug
  // cout << "before getRouting_table" << endl;
  // for (int i = 0; i < ROUTER_NUM; i++) {
  //   cout << (gateway.routing_table[i]).forward_router.ip << " ";
  // }
  // cout << "\n";

  // produce all Routing_table by gateway
  getRouting_table(gateway);
  writeJson(gateway);

  return 0;
}

// calculate lowest cost path between 2 routers
void dijkstra(int connection_matrix[ROUTER_NUM][ROUTER_NUM],
              int begin,
              int distance[ROUTER_NUM],
              int pre_router[ROUTER_NUM]) {
  // declare and initialize visited array
  int visited[ROUTER_NUM];
  memset(visited, 0, sizeof(visited));
  // declare and initializee distance array and each routers's precursor
  for (int i = 0; i < ROUTER_NUM; i++) {
    memset(pre_router, 0, sizeof(pre_router[ROUTER_NUM]));
  }
  for (int i = 0; i < ROUTER_NUM; i++) {
    distance[i] = connection_matrix[begin][i];
    if (distance[i] != INF) {
      pre_router[i] = begin;
    }
  }

  // min is the lowest edge for router i, min_index is next router's ip
  int min, min_index;
  for (int i = 0; i < ROUTER_NUM; i++) {
    min = INF;
    // find min and min_index
    for (int j = 0; j < ROUTER_NUM; j++) {
      if (!visited[j] && min > distance[j]) {
        min = distance[j];
        min_index = j;
      }
    }

    // set the next router is visited
    visited[min_index] = 1;
    // check whether through this router can reach other router easier or not
    for (int j = 0; j < ROUTER_NUM; j++) {
      // yes, store the path router in begin router to router j's path
      if (distance[j] > distance[min_index] + connection_matrix[min_index][j]) {
        distance[j] = distance[min_index] + connection_matrix[min_index][j];
        pre_router[j] = min_index;
      }
    }
  }

  // debug
  // for (int i = 0; i < ROUTER_NUM; i++) {
  //   cout << "vertex " << begin << " to vertex " << i
  //        << "'s lowest cost is: " << distance[i] << endl;
  //   cout << "the path to vertex" << i << " is : ";
  //   getPath(pre_router, begin, i);
  //   cout << "\n";
  // }
}

// realize cout the path to target by using stack to acquire each pre_router
void getPath(int pre_router[ROUTER_NUM], int begin, int target) {
  Stack stack;
  if (begin == target) {
    stack.push(target);
  }
  // push all the vertices on the path
  while (begin != target) {
    stack.push(target);
    target = pre_router[target];
  }
  cout << begin << " -> ";

  // take out all the value in the stack
  while (stack.size) {
    if (stack.size == 1) {
      cout << stack.pop();
    } else {
      cout << stack.pop() << " -> ";
    }
  }
}

void getRouting_table(struct Gateway& gateway) {
  // print for debug
  // cout << "after getRouting_table" << endl;
  // for (int i = 0; i < ROUTER_NUM; i++) {
  //   cout << (gateway.routing_table[i]).forward_router.ip << " ";
  // }
  // cout << "\n";

  int distance[ROUTER_NUM][ROUTER_NUM];
  // pre_router[i] means that beginning from Router i to Router j, each Router's
  // precursor Router of Router j
  int pre_router[ROUTER_NUM][ROUTER_NUM];
  for (int i = 0; i < ROUTER_NUM; i++) {
    dijkstra(gateway.connection_matrix, i, distance[i], pre_router[i]);
  }

  // print for debug
  // for (int i = 0; i < ROUTER_NUM; i++) {
  //   for (int j = 0; j < ROUTER_NUM; j++) {
  //     cout << "Router " << i << " to Router " << j
  //          << "'s lowest cost is: " << distance[i][j] << endl;
  //     cout << "the path to Router" << i << " is : ";
  //     getPath(pre_router[i], i, j);
  //     cout << "\n";
  //   }
  //   cout << "\n";
  // }

  // set begin and target Router
  cout << "Which Router is connecting with gateway recently?\n";
  Router source_router = {.ip = -1};
  cin >> source_router.ip;
  if (source_router.ip < 0 || source_router.ip >= ROUTER_NUM) {
    cout << "Your input is error! Please rebegin program\n";
    exit(0);
  }
  cout << "Which Router is your destination?\n";
  Router target_router = {.ip = -1};
  cin >> target_router.ip;
  if (source_router.ip < 0 || source_router.ip >= ROUTER_NUM) {
    cout << "Your input is error! Please rebegin program\n";
    exit(0);
  }

  // get path array
  Stack stack;
  int path[ROUTER_NUM];
  memset(path, 0, sizeof(path));

  // record the path by path[ROUTER_NUM]
  int begin = source_router.ip, target = target_router.ip;
  if (begin == target) {
    stack.push(target);
  }
  while (begin != target) {
    stack.push(target);
    target = pre_router[begin][target];
  }
  stack.push(source_router.ip);
  int i = 0;
  while (stack.size) {
    path[i++] = stack.pop();
  }

  // print for debug
  // i = 0;
  // while (path[i] != target_router.ip) {
  //   cout << path[i++] << " ";
  // }
  // cout << path[i] << "\n";

  // produce routing_table for each Router on the path
  i = 0;
  while (path[i] != target_router.ip) {
    struct Router local_router = {.ip = path[i]};
    struct Router forward_router = {.ip = path[i + 1]};
    gateway.routing_table[path[i]] = {.cost = distance[path[i]][path[i + 1]],
                                      .local_router = local_router,
                                      .source_router = source_router,
                                      .target_router = target_router,
                                      .forward_router = forward_router};
    i++;
  }
  // to limit temp variables survival period
  {
    struct Router temp_local_router = {.ip = path[i]};
    struct Router temp_forward_router = {.ip = path[i]};
    gateway.routing_table[path[i]] = {
        // this router must be the lastest one, so the cost must be 0
        .cost = 0,
        .local_router = temp_local_router,
        .source_router = source_router,
        .target_router = target_router,
        .forward_router = temp_forward_router};
  }
}

void writeJson(struct Gateway& gateway) {
  // define root node
  Json::Value root;

  // field of root
  Json::Value connection_matrix;
  for (int i = 0; i < ROUTER_NUM; i++) {
    for (int j = 0; j < ROUTER_NUM; j++) {
      connection_matrix[i][j] = gateway.connection_matrix[i][j];
    }
  }
  root["connection_matrix"] = connection_matrix;

  // field of root
  Json::Value routing_table_array;
  Json::Value routing_table;
  for (int i = 0; i < ROUTER_NUM; i++) {
    routing_table["cost"] = gateway.routing_table[i].cost;
    Json::Value router1;
    router1["ip"] = gateway.routing_table[i].local_router.ip;
    routing_table["local_router"] = router1;
    Json::Value router2;
    router2["ip"] = gateway.routing_table[i].source_router.ip;
    routing_table["source_router"] = router2;
    Json::Value router3;
    router3["ip"] = gateway.routing_table[i].target_router.ip;
    routing_table["target_router"] = router3;
    Json::Value router4;
    router4["ip"] = gateway.routing_table[i].forward_router.ip;
    routing_table["forward_router"] = router4;

    routing_table_array[i] = routing_table;
  }
  root["routing_table"] = routing_table_array;

  // cout << "StyledWriter:" << endl;
  Json::StyledWriter sw;
  // cout << sw.write(root) << endl << endl;

  //输出到文件
  ofstream os;
  os.open("attribution.json", std::ios::out | std::ios::trunc);
  if (!os.is_open())
    cout << "error：can not find or create the file which named \" attribution.json\"."
         << endl;
  os << sw.write(root);
  os.close();
}