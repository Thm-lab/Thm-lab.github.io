#include "printProject.h"

using namespace std;

void printProject() {
  cout << "This is a project for DataStructure homework!\n" << endl;
}