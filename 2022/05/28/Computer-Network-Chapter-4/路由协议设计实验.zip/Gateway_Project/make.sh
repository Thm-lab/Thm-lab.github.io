#!/bin/bash
if [ -d "./build" ]; then
    rm -r build
    mkdir build
else
    mkdir build
fi
cd build || exit
cmake .. &&
    make &&
    cd ..
