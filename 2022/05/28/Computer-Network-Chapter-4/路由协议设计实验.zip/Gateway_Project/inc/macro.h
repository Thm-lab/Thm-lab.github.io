#pragma once

#define ROUTER_NUM 8
#define INF 10000
// #define INF 2147483647 it is too big

struct Router {
  int ip;
};

struct Routing_table {
  int cost;
  Router local_router;
  Router source_router;
  Router target_router;
  Router forward_router;
};

struct Gateway {
  int connection_matrix[ROUTER_NUM][ROUTER_NUM];
  struct Routing_table routing_table[ROUTER_NUM];
};

class Stack {
 public:
  Stack() = default;
  int stack[ROUTER_NUM];
  int size = 0;
  void push(int x) { stack[size++] = x; }
  int pop() { return stack[--size]; }
};